"""VLC Bookmark Studio -- playlist-aware visual bookmarking and looping for VLC (spec #198)."""

__version__ = "0.8.0"
