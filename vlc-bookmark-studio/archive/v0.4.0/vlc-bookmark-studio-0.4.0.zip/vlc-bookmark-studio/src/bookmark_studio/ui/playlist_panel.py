"""VLC playlist sidebar: filter, bookmark-count column, Follow VLC mode (spec #145-#148)."""
from __future__ import annotations

from PySide6.QtCore import QSignalBlocker, Signal
from PySide6.QtGui import QBrush, QColor, QFont
from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from bookmark_studio.playback.status import VlcPlaylistItem
from bookmark_studio.ui.qt_helpers import top_level_rows

COLUMNS = ["Title", "Artist", "Duration", "Bookmarks", "Status"]

# The current song's row is tinted: green while it plays, blue while it is only
# loaded (paused/stopped).
_ACTIVELY_PLAYING_COLOR = QColor("#8fd98f")
_CURRENT_NOT_PLAYING_COLOR = QColor("#a9c9f5")
_NOT_CURRENT_BRUSH = QBrush()


class PlaylistPanel(QWidget):
    item_selected = Signal(int)  # vlc_id
    item_double_clicked = Signal(int)  # vlc_id -- play in VLC (spec #147)
    follow_vlc_toggled = Signal(bool)
    launch_vlc_requested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._items: list[VlcPlaylistItem] = []
        self._bookmark_counts: dict[int, int] = {}
        self._current_playing_id: int | None = None
        self._is_actively_playing = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # Opens VlcLaunchDialog: attach to a running VLC, launch one with a playlist,
        # or play inside the app.
        self._launch_vlc_button = QPushButton("Launch VLC...", self)
        self._launch_vlc_button.setToolTip(
            "Attach to an already-open VLC instance, or launch a new one with a playlist"
        )
        self._launch_vlc_button.clicked.connect(self.launch_vlc_requested.emit)
        layout.addWidget(self._launch_vlc_button)

        # Connection status and the Follow checkbox, right under the button that
        # makes the connection.
        status_row = QHBoxLayout()
        self._connection_label = QLabel("● Offline", self)
        connection_font = QFont()
        connection_font.setPointSize(10)
        connection_font.setBold(True)
        self._connection_label.setFont(connection_font)
        self._connection_label.setStyleSheet("color: #a33;")
        status_row.addWidget(self._connection_label)

        self._follow_checkbox = QCheckBox("Follow currently playing VLC song", self)
        self._follow_checkbox.setChecked(True)
        self._follow_checkbox.toggled.connect(self.follow_vlc_toggled.emit)
        status_row.addWidget(self._follow_checkbox)
        status_row.addStretch(1)
        layout.addLayout(status_row)

        # Directly above the tree it filters.
        self._filter_edit = QLineEdit(self)
        self._filter_edit.setPlaceholderText("Filter...")
        self._filter_edit.textChanged.connect(self._apply_filter)
        layout.addWidget(self._filter_edit)

        self._tree = QTreeWidget(self)
        self._tree.setColumnCount(len(COLUMNS))
        self._tree.setHeaderLabels(COLUMNS)
        self._tree.itemSelectionChanged.connect(self._on_selection_changed)
        self._tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self._tree)

    def set_playlist(
        self, items: list[VlcPlaylistItem], bookmark_counts: dict[int, int] | None = None
    ) -> None:
        # Skip the rebuild entirely when nothing actually changed -- called on every
        # ~2s playlist poll regardless, and a full _tree.clear() + repopulate tears
        # down and recreates every row, wiping the current selection and scroll
        # position each time even when the playlist is identical. Same class of bug
        # fixed in set_current_playing() below, just on a longer, less noticeable cycle.
        normalized_counts = bookmark_counts or {}
        if items == self._items and normalized_counts == self._bookmark_counts:
            return
        self._items = items
        self._bookmark_counts = normalized_counts
        self._rebuild()

    def set_current_playing(self, vlc_id: int | None, *, is_playing: bool = False) -> None:
        """Updates only the playing-row highlight on the existing rows. Rebuilding the
        rows here (every status poll) would replace the items between the two clicks
        of a double-click, which Qt then never reports, and would reset the selection
        and scroll position.

        `is_playing` is the player's actual state (green) as opposed to the song
        merely being loaded (blue).
        """
        if vlc_id == self._current_playing_id and is_playing == self._is_actively_playing:
            return
        self._current_playing_id = vlc_id
        self._is_actively_playing = is_playing
        for row in top_level_rows(self._tree):
            _set_row_playing(row, row.data(0, 32) == vlc_id, is_playing)

    def select_item(self, vlc_id: int | None) -> None:
        """Highlights the row for `vlc_id` (selecting a bookmark selects its song).
        Setting the current item fires the normal
        itemSelectionChanged -> item_selected signal chain, so Application's existing
        _on_playlist_item_selected handles the actual waveform/follow-state switch;
        this method only needs to move the highlight.
        """
        if vlc_id is None:
            self._tree.clearSelection()
            return
        for row in top_level_rows(self._tree):
            if row.data(0, 32) == vlc_id:
                self._tree.setCurrentItem(row)
                return

    def set_connected(self, connected: bool) -> None:
        if connected:
            self._connection_label.setText("● Connected")
            self._connection_label.setStyleSheet("color: #2a2;")
        else:
            self._connection_label.setText("● Offline")
            self._connection_label.setStyleSheet("color: #a33;")

    def set_follow_vlc(self, enabled: bool, *, notify: bool = True) -> None:
        """Programmatic version of the checkbox -- used when previewing a different,
        not-currently-playing song single-clicks the checkbox off (see
        Application._on_playlist_item_selected) so live playback progression doesn't
        yank the waveform view away from what the user just chose to look at.

        notify=False changes the box without emitting follow_vlc_toggled: for callers
        that are about to switch the displayed song themselves, where the toggle
        handler's own "snap back to the playing song" would load the wrong song first.
        """
        blocker = QSignalBlocker(self._follow_checkbox) if not notify else None
        try:
            self._follow_checkbox.setChecked(enabled)
        finally:
            if blocker is not None:
                blocker.unblock()

    def follow_vlc_enabled(self) -> bool:
        return self._follow_checkbox.isChecked()

    def _rebuild(self) -> None:
        self._tree.clear()
        for item in self._items:
            row = QTreeWidgetItem(
                [
                    item.name,
                    "",
                    _format_duration(item.duration_s),
                    str(self._bookmark_counts.get(item.vlc_id, 0)),
                    "",
                ]
            )
            row.setData(0, 32, item.vlc_id)  # Qt.ItemDataRole.UserRole == 32
            _set_row_playing(row, item.vlc_id == self._current_playing_id, self._is_actively_playing)
            self._tree.addTopLevelItem(row)
        # Fit the columns to their contents on each rebuild (still resizable by hand).
        for column in range(len(COLUMNS)):
            self._tree.resizeColumnToContents(column)
        self._apply_filter(self._filter_edit.text())

    def _apply_filter(self, text: str) -> None:
        needle = text.strip().lower()
        for row in top_level_rows(self._tree):
            visible = not needle or needle in row.text(0).lower()  # column 0 == Title
            row.setHidden(not visible)

    def _on_selection_changed(self) -> None:
        selected = self._tree.selectedItems()
        if selected:
            self.item_selected.emit(selected[0].data(0, 32))

    def _on_item_double_clicked(self, item: QTreeWidgetItem, _column: int) -> None:
        self.item_double_clicked.emit(item.data(0, 32))


def _set_row_playing(row: QTreeWidgetItem, is_current: bool, is_playing: bool) -> None:
    if is_current:
        brush = QBrush(_ACTIVELY_PLAYING_COLOR if is_playing else _CURRENT_NOT_PLAYING_COLOR)
    else:
        brush = _NOT_CURRENT_BRUSH
    for column in range(len(COLUMNS)):
        row.setBackground(column, brush)


def _format_duration(duration_s: float | None) -> str:
    if duration_s is None or duration_s <= 0:  # VLC reports -1 for "not parsed yet"
        return ""
    total = int(duration_s)
    hours, rest = divmod(total, 3600)
    minutes, seconds = divmod(rest, 60)
    return f"{hours}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes}:{seconds:02d}"
